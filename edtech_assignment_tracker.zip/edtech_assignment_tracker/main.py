from fastapi import FastAPI
from starlette.middleware.sessions import SessionMiddleware

app = FastAPI()

app.add_middleware(SessionMiddleware, secret_key="your-secret-key")

# Include routers
from routers import user, assignment
app.include_router(user.router)
app.include_router(assignment.router)
