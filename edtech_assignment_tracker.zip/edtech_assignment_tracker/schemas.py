from pydantic import BaseModel
from datetime import date

class AssignmentBase(BaseModel):
    subject: str
    title: str
    due_date: date
    description: str

class AssignmentCreate(AssignmentBase):
    pass

class Assignment(AssignmentBase):
    id: int

    class Config:
        orm_mode = True
