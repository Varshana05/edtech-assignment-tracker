from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="templates")

@router.get("/create-assignment", response_class=HTMLResponse)
async def create_assignment_form(request: Request):
    return templates.TemplateResponse("create_assignments.html", {"request": request})
