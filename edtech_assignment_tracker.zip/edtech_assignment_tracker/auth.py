users = {}

def authenticate_user(username: str, password: str):
    return users.get(username) == password

def register_user(username: str, password: str):
    if username in users:
        return False
    users[username] = password
    return True
